<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <a role="button" name="Portada" href="index.php" class="btn btn-primary">Portada</a>      
          <a role="button" name="Entrar Articulo" href="addArt.php" class="btn btn-primary">Entrar Articulo</a>
          <a role="button" name="Add" href="addCliente.php" class="btn btn-primary">Anadir Cliente</a>
          <a role="button" name="Crear" href="crear_venta.php" class="btn btn-primary">Crear Venta</a>
          <a role="button" name="Lista" href="venta.php" class="btn btn-primary">Listado de Ventas</a>
    </div>
  </div>
</nav>