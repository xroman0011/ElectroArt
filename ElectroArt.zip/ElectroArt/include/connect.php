<?php
//conexión a la base de datos
$con = mysqli_connect("localhost", "root", "", "electroart");

?>